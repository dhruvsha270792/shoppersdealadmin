shoppersApp.controller('mainController',['$scope', function($scope){
	
}]);