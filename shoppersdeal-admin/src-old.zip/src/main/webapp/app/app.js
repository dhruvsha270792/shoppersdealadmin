'use strict'

var shoppersApp=angular.module('shoppersApp',[]);