package com.nexusdevs.shoppersdeal.admin.common;

public enum AddressType {
	HOME, OFFICE;
}
