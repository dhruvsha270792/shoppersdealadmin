package com.nexusdevs.shoppersdeal.admin.configuration;

public class ApiConfiguration {

	private String apiUrl;

	public String getApiUrl() {
		return apiUrl;
	}

	public void setApiUrl(String apiUrl) {
		this.apiUrl = apiUrl;
	}

}
