package com.nexusdevs.shoppersdeal.admin.db;

public class RedisManager {

}
