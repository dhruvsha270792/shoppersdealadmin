package com.nexusdevs.shoppersdeal.admin.common;

public enum SortOrder {
	ASCENDING, DESCENDING
}
