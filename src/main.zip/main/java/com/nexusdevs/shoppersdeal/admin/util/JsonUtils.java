package com.nexusdevs.shoppersdeal.admin.util;

public class JsonUtils {}