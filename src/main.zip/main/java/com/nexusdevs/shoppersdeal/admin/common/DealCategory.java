package com.nexusdevs.shoppersdeal.admin.common;

public enum DealCategory {
	normal, topRated, special, hotDeals;
}
